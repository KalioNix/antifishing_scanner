// popup.js
const criminalApiKey = "UVUY39KrwS1bi4G3fAwzxWLQDeFEJ5Xy3POAiDlmigNWITMORV7kA06XT2xB";
const gonggongDataKey = "SDtKAomEaycQLYC8%2BllD4XsPYPpmUtPMwGh08a759cSrFL7o%2By1rv5%2FzqU9TCjpKcmWcbkzeWcnaIF7c%2BE7CUA%3D%3D";

const baseUrl = "https://api.criminalip.io/v1/domain/reports?query=";
const ipSummaryUrl = "https://api.criminalip.io/v1/ip/summary?ip=";
const maliciousUrl = "https://api.criminalip.io/v1/feature/ip/malicious-info?ip=";

let result = "";
let plus = 0;

function parseDomain(url) {
  const parsedUrl = new URL(url);
  let domain = parsedUrl.hostname;
  if (domain.startsWith('www.')) {
    domain = domain.replace('www.', '');
  }
  return domain;
}

async function getIpAddress() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const currentTab = tabs[0];

  // URL을 구문 분석하여 호스트 이름(도메인 이름)을 추출합니다.
  const parsedUrl = new URL(currentTab.url);
  let domainName = parsedUrl.hostname;

  // 도메인이 'www.'로 시작하면 필요한 경우 제거합니다.
  if (domainName.startsWith('www.')) {
    domainName = domainName.replace('www.', '');
  }

  // 도메인 이름을 사용하여 IP 주소를 가져옵니다.
  const dnsResult = await fetch(`https://dns.google/resolve?name=${domainName}`);
  const dnsData = await dnsResult.json();
  const ipAddress = dnsData.Answer[0].data;

  return ipAddress;
}



async function changeDomainIP(x) {
  const ip = await getIpAddress();
  //result += ";";
  //result += ip;
  return ip;
}


async function checkDnsSafety(domain) {
  const url = `${baseUrl}${domain}`;
  const headers = {
    'x-api-key': criminalApiKey
  };

  try {
    const response = await fetch(url, { headers });
    const domainReData = await response.json();
    const score = domainReData.data.reports[0].score;

    switch (score) {
      case "Critical":
        console.log(`${domain}은(는) 매우 위험합니다!!`);
        break;
      case "Dangerous":
        console.log(`${domain}은(는) 위험합니다!!`);
        break;
      case "Moderate":
        console.log(`${domain}은(는) 주의할 필요가 있어요.`);
        break;
      case "Low":
        console.log(`${domain}은(는) 괜찮아요.`);
        break;
      case "Safe":
        console.log(`${domain}은(는) 안전한 사이트에요.`);
        break;
    }
  } catch (error) {
    console.error(error);
  }
}

async function checkIPSafe(ip) {
  const url = `${ipSummaryUrl}${ip}`;
  const headers = {
    'x-api-key': criminalApiKey
  };

  try {
    const response = await fetch(url, { headers });
    const ipReData = await response.json();
    const inboundScore = ipReData.score.inbound;
    const outboundScore = ipReData.score.outbound;
    let totalScore = (inboundScore * 10) + (outboundScore * 10);
    const country_code = ipReData.country_code;
    result += `${100 - totalScore}%`; // ;${country_code.toUpperCase()}
    return { totalScore, country_code };
  } catch (error) {
    console.error(error);
  }
}

async function whoisCheck(domain) {
    const whoisApiUrl = `http://apis.data.go.kr/B551505/whois/domain_name?serviceKey=${gonggongDataKey}&query=${domain}&answer=json`;

    try {
      const response = await fetch(whoisApiUrl);
      const whoisData = await response.json();
      const resultCode = whoisData.response.result.result_code;
      if (resultCode === '10000') {
        //result += ";한국인터넷진흥원 등록 도메인입니다.";
        plus = 10;
      } else {
        // result += ";한국인터넷진흥원에는 없는 도메인입니다.";
      }
    } catch (error) {
      console.error(error);
    }
}

async function openPort(ip) {
    const url = `${maliciousUrl}${ip}`;
    const headers = {
      'x-api-key': criminalApiKey
    };
  
    try {
      const response = await fetch(url, { headers });
      const malReData = await response.json();
      const count = malReData.current_opened_port.count;
      const portNum = malReData.current_opened_port.data.map(item => item.port);
      const res = portNum.join(', ');
  
      // result += `;${res}`;
    } catch (error) {
      console.error(error);
    }
}

function drawGauge(max, classname, colorname) {
  let i = 0;
  const interval = 1;
  const totalSteps = 100 / interval;

  const func1 = setInterval(function () {
    if (i <= totalSteps) { 
      colorGauge((max / 100) * i * interval, classname, colorname);
      i++;
    } else {
      clearInterval(func1);
    }
  }, 10);
}

function colorGauge(score, classname, colorname) {
  const gradientColor = (score === 0) ? "#e9ecef" : `${colorname} 0% ${score}%, #e9ecef ${score}% 100%`;
  $(classname).css({
    "background": `conic-gradient(${gradientColor})`
  });
}

function getColor(score) {
  if (score >= 80) {
    return "#3D81F5";
  } else if (score >= 60) {
    return "#12BA69";
  } else if (score >= 40) {
    return "#FCC436";
  } else {
    return "#DD493C";
  }
}

document.addEventListener('DOMContentLoaded', function () {
  const checkButton = document.getElementById('checkButton');
  checkButton.addEventListener('click', async () => {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const currentTab = tabs[0];
    const x = currentTab.url;
    const domainElement = document.getElementById('domain');
    const resultElement = document.getElementById('result');

    domainElement.textContent = parseDomain(x);
    resultElement.textContent = '검사 중...';

    try {
      const changedDomain = parseDomain(x);
      await whoisCheck(changedDomain);
      const ip = await changeDomainIP(changedDomain);
      const { totalScore } = await checkIPSafe(ip);

      // Set the result in the HTML
      resultElement.textContent = result;

      // Update the gauge
      drawGauge(100 - totalScore, '.pie-chart1', getColor(100 - totalScore));

      console.log(result);
    } catch (error) {
      console.error(error);
    }
  });
});