$(window).ready(function() {
    var score = 30
    //var score = document.querySelector('#content > div:nth-child(4) > div > div.col-xl-8.col-lg-5 > div > div.table-responsive > table > tbody > tr:nth-child(3) > td').innerText;
    if(parseInt(score)>=80){
        var color="#3D81F5";
    } else if(parseInt(score)>=60){
        var color="#12BA69";
    } else if(parseInt(score)>=40){
        var color="#FCC436";
    } else{
        var color="#DD493C";
    }
    $('.pie-chart1 .center').text(score + '%');
    draw(score, '.pie-chart1', color);
});

function draw(max, classname, colorname) {
    var i = 1;
    var func1 = setInterval(function() {
        if (i <= max) {
            color1(i, classname, colorname);
            i++;
        } else {
            clearInterval(func1);
        }
    }, 10);
}

function color1(i, classname, colorname) {
    var gradientColor = (i == 0) ? "#e9ecef" : colorname + " 0% " + i
            + "%, #e9ecef " + i + "% 100%";
    $(classname).css({
        "background" : "conic-gradient(" + gradientColor + ")"
    });
}

function getParameterByName(name) {
    var url = window.location.href;
    name = name.replace(/[\[\]]/g, '\\$&');
    var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'), results = regex
            .exec(url);
    if (!results)
        return null;
    if (!results[2])
        return '';
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
}